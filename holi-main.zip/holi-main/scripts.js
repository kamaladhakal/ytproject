setTimeout(function() {
    var myinfo = document.getElementById('myinfo');
    myinfo.style.display = 'none';
}, 10000);
console.log(dhakalkiran.com.np);
